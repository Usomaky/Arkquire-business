<template>
    <Navbar />
    <Header />
    <section class="w-full wrapper">
        <div>BOOKMARKED BUSINESS</div>
        <div header="Bookmarked Businesses" :style="{ width: '26rem' }">
            <div v-if="localBookmarks.length === 0" class="text-center text-gray-500">
                No bookmarks found.
            </div>
            <ul v-else>
                <li v-for="bookmark in localBookmarks" :key="bookmark">
                    {{ bookmark_name }}
                    <button @click="removeBookmark(bookmark.id)">Remove</button>
                </li>
            </ul>
            <button v-if="localBookmarks.length > 0" @click="removeAllBookmarks">Remove All Bookmarks</button>
        </div>
    </section>
    <Footer />

</template>

<script setup>
import { Head } from '@inertiajs/vue3';
import Navbar from '../Components/Navbar.vue';
import Footer from '../Components/Footer.vue';
import Categories from '../Components/Business/Categories.vue';
import Details from '../Components/Business/Details.vue';
import { onMounted, ref, defineProps, defineOptions, watch, defineEmits } from 'vue';
import Dialog from 'primevue/dialog';
import { Inertia } from '@inertiajs/inertia';
import { router } from '@inertiajs/vue3';

import Services from '../Layouts/Services.vue';
defineOptions({ layout: Services });

// const props = defineProps({
//     business: Object
// });

const props = defineProps({
    visible: {
        type: Boolean,
        default: false,
    },
    bookmarks: {
        type: Array,
        default: () => [], // Ensure default is an empty array
    },
});

const emit = defineEmits(['update:visible']);

//   const show = ref(props.visible);
const localBookmarks = ref([...props.bookmarks]);
const processing = ref(false);
const messages = ref([]);
let count = ref(0);

console.log('Bookmarked Business: ' );

//   watch(() => props.visible, (visible) => {
//     show.value = visible;
//     if (visible) {
//       fetchBookmarks();
//     }
//   });

//   watch(() => show.value, (visible) => {
//     emit('update:visible', visible);
//   });

const fetchBookmarks = () => {
    Inertia.get('/bookmarks', {}, {
        onSuccess: (page) => {
            localBookmarks.value = page.props.bookmarks || []; // Ensure bookmarks is always an array
        },
        onError: () => {
            showMessage('error', 'Failed to fetch bookmarks.');
        }
    });
};

const removeBookmark = (id) => {
    processing.value = true;
    Inertia.delete(`/bookmarks/${id}`, {
        onFinish: () => {
            localBookmarks.value = localBookmarks.value.filter(bookmark => bookmark.id !== id);
            showMessage('success', 'Bookmark removed successfully.');
            processing.value = false;
        },
        onError: () => {
            showMessage('error', 'Failed to remove bookmark.');
            processing.value = false;
        }
    });
};

const removeAllBookmarks = () => {
    processing.value = true;
    Inertia.delete(`/bookmarks`, {
        onFinish: () => {
            localBookmarks.value = [];
            showMessage('success', 'All bookmarks removed successfully.');
            processing.value = false;
        },
        onError: () => {
            showMessage('error', 'Failed to remove all bookmarks.');
            processing.value = false;
        }
    });
};

const showMessage = (severity, content) => {
    messages.value = [{ severity, content, id: count.value++ }];
};
</script>

<style scoped>
* {
    font-family: "DM Sans", sans-serif;
}
</style>
