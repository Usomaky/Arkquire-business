<?php

use App\Http\Controllers\Admin\BusinessController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\CategoryController;
use App\Models\Category;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;


Route::post('/login', function(){});

Route::middleware(['super_admin'])->group(function () {
    Route::get('/dashboard', function(){
        return Inertia::render('Admin/Dashboard');
    });

    // User routes
    Route::get('/users', [UserController::class, 'index']);

    // Business routes
    Route::get('/businesses', [BusinessController::class, 'index']);

    // category routes
    Route::get('/category', [CategoryController::class, 'index']);
    
    Route::post('/category', [CategoryController::class, 'store'])->name('categories.store');
    Route::put('/category', [CategoryController::class, 'update'])->name('categories.update');
    Route::delete('/category/{id}', [CategoryController::class, 'destroy']);
});
